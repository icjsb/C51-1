#ifndef __KEYPROCESS_H__
#define __KEYPROCESS_H__

void vKeyProcess(unsigned char ucKeyCode);

#endif