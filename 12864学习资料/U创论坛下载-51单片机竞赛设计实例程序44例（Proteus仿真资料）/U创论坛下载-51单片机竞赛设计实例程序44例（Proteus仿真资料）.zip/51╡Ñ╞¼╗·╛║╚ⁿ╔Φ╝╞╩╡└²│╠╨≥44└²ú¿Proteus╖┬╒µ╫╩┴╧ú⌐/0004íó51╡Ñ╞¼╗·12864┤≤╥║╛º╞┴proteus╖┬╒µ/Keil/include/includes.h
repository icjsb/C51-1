#ifndef __INCLUDES_H__
#define __INCLUDES_H__

#include <at89x51.h>

#include "LCD12864.h"
#include "LCDShowMap.h"
#include "GameGraph.h"

#include "KeyScan.h"
#include "KeyProcess.h"

#endif