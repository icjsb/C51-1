#include <REGX51.H>
#include "HyperTerminal.h"

void main(void)
{
	InitHyperTerminal();

	while(1)
	{
		RunHyperTerminal();
	}
}

